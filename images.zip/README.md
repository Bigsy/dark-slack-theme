Chrome extension for a arc-dark inspired theme for slack.

https://chrome.google.com/webstore/detail/dark-theme-for-slack/begdfkhhegoognioipgofimponkeiiah

![alt tag](https://cloud.githubusercontent.com/assets/354898/9326628/07f19d54-4593-11e5-87ce-1f9a6037d305.png)
